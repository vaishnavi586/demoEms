package com.example.daoImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.dao.EmployeeDao;
import com.example.model.Employee;
import com.example.model.EmployeeMapper;

public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	JdbcTemplate jdbctemplate;

	@Override
	public List<Employee> getAllEmployees() {
		return jdbctemplate.query("select * from employee_table", new EmployeeMapper());
	}

	@Override
	public Employee getEmployeeById(int id) {
		Employee employee = null;
		try {
			employee = jdbctemplate.queryForObject("select * from employee_table where id=?", new Object[] { id },
					new EmployeeMapper());
		} catch (Exception ex) {
			System.out.println("exception" + ex);

		}
		// TODO Auto-generated method stub
		return employee;
	}

	@Override
	public Employee updateEmployee(int id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee createEmployee(Employee employee) {
		jdbctemplate.update("insert into employee_table(name,salary,age,address,role) values (?,?,?,?,?)",
				new Object[] { employee.getName(), employee.getSalary(), employee.getAge(), employee.getAddress(),
						employee.getRole() });

		return getEmployeeById(employee.getId());

	}

	@Override
	public boolean deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return false;
	}

}
