package com.example.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.EmployeeDao;
import com.example.model.Employee;
import com.example.model.Response;

@RestController
@RequestMapping("/employees")
public class EMSController {
	@Autowired
	public EmployeeDao dao1;

	@GetMapping(value="/all",produces=MediaType.APPLICATION_JSON_VALUE)
	// public List<post> getAllQuestions() {
	// return dao.getAllQuestions();

	// }
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> employee = dao1.getAllEmployees();
		if (employee.isEmpty()) {

			return new ResponseEntity<List<Employee>>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<List<Employee>>(employee, HttpStatus.OK);
	}

	//@GetMapping("/{id}")
	@GetMapping(value="/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int id) {
		Employee employee = dao1.getEmployeeById(id);
		if (employee == null) {

			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);

		}
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}
	//@PostMapping(value="/post",produces=MediaType.APPLICATION_JSON_VALUE)

	@PostMapping("/post")
	public ResponseEntity<Employee> createEmployee( @RequestBody Employee employee) {
	//public ResponseEntity<Response> createEmployee( @RequestBody Employee employee) {
		//var responsePojo = new Response();
		Employee Emp = dao1.createEmployee(employee);
		//if (Emp == null) {
			//responsePojo.setCode(HttpStatus.NOT_ACCEPTABLE.toString());
			//responsePojo.setMessage("please fill every column i.e. name,age,salary,address,role");
			//return new ResponseEntity<>(responsePojo, HttpStatus.NOT_ACCEPTABLE);
		//	return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);

		//} else {

			//responsePojo.setMessage("employee details created successfully ");
			return new ResponseEntity<Employee>(Emp,HttpStatus.OK);
		//}
//Employee createEmployee(@RequestBody Employee employee) {
	//	 return dao1.createEmployee(employee);

	}

	@PutMapping("/{id}")
	public ResponseEntity<Response> updateEmployee( @RequestBody Employee employee, @PathVariable int id) {
		var responsePojo = new Response();
		Employee existingEmp = dao1.getEmployeeById(id);
		if (existingEmp == null) {
			responsePojo.setCode(HttpStatus.NOT_FOUND.toString());
			responsePojo.setMessage("employee  not found! Please enter an exixting employeeid to modify");
			return new ResponseEntity<>(responsePojo, HttpStatus.NOT_FOUND);

		} else {

			dao1.updateEmployee(id, employee);
			return new ResponseEntity<>(HttpStatus.OK);
		}
	}

	@DeleteMapping(path = "/{id}")
	public ResponseEntity<Response> deleteEmployee(@PathVariable("id") Integer id) {
		var responsePojo = new Response();
		Employee employee = dao1.getEmployeeById(id);
		if (employee == null) {
			responsePojo.setCode(HttpStatus.GONE.toString());
			responsePojo.setMessage("employee Sucessfully Deleted");
			return new ResponseEntity<>(responsePojo, HttpStatus.GONE);

		} else {

			dao1.deleteEmployee(id);
			responsePojo.setMessage("employee Sucessfully Deleted");
			return new ResponseEntity<>(responsePojo, HttpStatus.GONE);
		}
	}
}
