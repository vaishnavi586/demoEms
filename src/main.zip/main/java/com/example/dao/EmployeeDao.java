package com.example.dao;

import java.util.List;

import com.example.model.Employee;

public interface EmployeeDao {
	List<Employee> getAllEmployees();

	public Employee getEmployeeById(int id);

	public Employee updateEmployee(int id, Employee employee);

	public Employee createEmployee(Employee employee);

	public boolean deleteEmployee(int id);

}
