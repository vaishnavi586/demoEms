package com.example.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeMapper implements RowMapper<Employee> {
	public Employee mapRow(ResultSet resultSet, int i) throws SQLException {
		Employee employee =new Employee();
		employee.setId(resultSet.getInt("id"));
		employee.setName(resultSet.getString("name"));
		employee.setSalary(resultSet.getInt("salary"));
		employee.setAge(resultSet.getInt("age"));
		employee.setAddress(resultSet.getString("address"));
		employee.setRole(resultSet.getString("role"));
		
		return employee;

}
}


