package com.example.model;
public class Response {

	private String message;
	private String code;

	public Response() {

	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String string) {
		this.message = string;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	
}